import React from 'react'

function Cote() {
  return (
    <>
      <div id='cotePg'>
        <div id="cotecard">
            
        </div>
      </div>
    </>
  )
}

export default Cote
